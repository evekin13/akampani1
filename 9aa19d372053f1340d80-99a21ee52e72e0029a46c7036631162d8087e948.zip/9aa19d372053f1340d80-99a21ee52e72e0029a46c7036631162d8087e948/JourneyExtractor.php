<?php

/*
Journal (by Journey) extractor

Journey is a great Diary app for Android and Google Chrome. But, your files are
only accessible by Journey itself.

Do you want to move away from Journey to another diary app? Do you want to have
a readable export of your diary? This script converts Journey backup/export
files to managable Markdown files. One file per month.

Copyright (c) 2015, Rogier van den Berg / www.rogiervandenberg.nl

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/* Extract your Journey backup and specify the folder below */
define("JOURNEYBACKUPDIR", "./journey-16044xxxxxxxx"); // <- Set this into the subfolder with your export, based on where this php-script is

/* Where your Markdown export will be written */
define("JOURNEYEXPORTDIR", "./export/");

/* Define your timezone */
date_default_timezone_set('Europe/Amsterdam');  // <- Set this correctly for your times to show up correctly

/* Set output language */
if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
	// Using Windows
	setlocale(LC_TIME, "esp_esp"); // <- Using Windows? Set your language here according to http://msdn.microsoft.com/en-us/library/cdax410z%28v=vs.90%29.aspx
} else {
	// Not using Windows
	setlocale(LC_TIME, "es_ES"); // <- Not using windows (Mac, Linux)? Set your ISO Language/Country Code, based on e.g. http://www.lingoes.net/en/translator/langcode.htm
}

// First make sure there is an export directory
if (!is_dir(JOURNEYEXPORTDIR)) {
	mkdir(JOURNEYEXPORTDIR);
}

// This is where we store all text of the Diary
$diary = array();

// Iterate through all files in Journey-backupdir
$dir = new DirectoryIterator(JOURNEYBACKUPDIR);
foreach ($dir as $fileinfo) {
if (!$fileinfo->isDot() && ( $fileinfo->getExtension() == 'json')) {
        processJourneyJsonFile($fileinfo->getPathname(), $diary);
    }
}

// Sort diary-data and start writing Markdownfiles
ksort($diary);
writeMarkdownfiles($diary);

// Provide the json-file and $diary-placeholder for getting all necessary data
function processJourneyJsonFile ($jsonfile, &$diary) {
	$journalData = json_decode(file_get_contents($jsonfile));
	//var_dump($journalData); //For debugging

	$diary[$journalData->date_journal/1000]['text'] = "## " . ucfirst(strftime("%A, %x %R", $journalData->date_journal/1000)) . "\r\n" . str_replace("# ", "### ", strip_tags($journalData->text)) . "\r\n";
	$diary[$journalData->date_journal/1000]['tags'] = $journalData->tags;
	$diary[$journalData->date_journal/1000]['photos'] = $journalData->photos;
}

// Writes markdown-files based on $diary array
function writeMarkdownfiles ($diary) {

	//Data is written per entry in a separate file per date
	foreach ($diary as $date => $diaryEntry)
	{
		$dateHeading = strftime('%B %Y', $date) . "\r\n\r\n";
		$filename = JOURNEYEXPORTDIR . date('Y-m.F', $date) . ".md";
		$text = $diaryEntry['text'];

		if(count($diaryEntry['photos']) > 0) {
			$text .= "\r\n";
			foreach ($diaryEntry['photos'] as $photo) {
				$text .= "![](" . JOURNEYEXPORTDIR . $photo . ")";
				processJourneyAttachments($photo);
			}
		}
		

		if(count($diaryEntry['tags']) > 0) {
			$text .= "\r\n";
			foreach ($diaryEntry['tags'] as $tag) {
				$text .= "`" . $tag . "` ";
			}
		}

		if (file_exists($filename)) {
		    file_put_contents($filename, $text . "\r\n\r\n", FILE_APPEND | LOCK_EX);
		} else {
			file_put_contents($filename, "# " . $dateHeading . $text . "\r\n\r\n", FILE_APPEND | LOCK_EX);
		}

		echo date(DATE_RFC2822, $date) . " has been written\r\n";	
	}
}

// Copies attachments to export-dir
function processJourneyAttachments ($attachment) {
	if (!copy(JOURNEYBACKUPDIR . $attachment, JOURNEYEXPORTDIR . $attachment)) {
    	echo "failed to copy " . $attachment . "...\n";
	}
}